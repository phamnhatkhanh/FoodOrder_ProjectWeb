<?php include('z.element_web/head.php') ?>

    <!--CONTENT WEB-->
    <div class="main-concept">
        <div class="wapper">
            <h2>MANAGE FOOD</h2>

            <div><?php 
                if(isset($_SESSION['add_food'])){
                    echo $_SESSION['add_food']; // lưu được ngoài text + div +align của div -> lợi hại thật.
                    unset($_SESSION['add_food']);
                }
                if(isset($_SESSION['delete_food'])){
                    echo $_SESSION['delete_food'];
                    unset($_SESSION['delete_food']);
                }
                if(isset($_SESSION['update_food'])){
                    echo $_SESSION['update_food'];
                    unset($_SESSION['update_food']);
                }

            ?></div>
            
            <br>
            <a href="add_food.php" class="btn-add"><b>Add Food</b></a>
            <br>
            <br>
            <table class="format-table">
                <tr>
                        <th>S.N</th>
                        <th>Title</th>
                        <th>Price</th>
                        <th>Image</th>
                        <th>Featured</th>
                        <th>Active</th>
                        <th>Action</th>
                    </tr>
                <!--Đẩy DATA từ DB vào Bảng-->
                <?php
                    //Create a query
                        $sql="SELECT * FROM tbl_food";
                    // Excuting query
                        $res=mysqli_query($connect_DB,$sql);
                    //Check Excuting query
                        if($res==true){
                            $count=mysqli_num_rows($res);
                            $sn=1;
                            if($count>0){
                                while($row=mysqli_fetch_assoc($res)){
                                    $id=$row['id'];
                                    $title=$row['title'];
                                    //  $description=$row['description'];
                                    $price=$row['price'];
                                    $image=$row['image_name'];
                                    $featured=$row['fearture'];
                                    $active=$row['active'];
                                    
                                ?>
                                <tr>
                                <td><?php echo $sn++;?></td>
                                <td><?php echo $title;?></td>
                                <td><?php echo $price;?></td>
                                <td>
                                    <?php
                                        if($image!=""){
                                        ?>
                                            <img class ="align_image" src="<?php echo SITE_URL;?>images/food/<?php echo $image?>  "> <!--sao nó có thẻ tự tìm được file trong thư mục đó nhỉ ??--->
                                        <?php
                                        }else{
                                            echo '
                                            <div class ="align_text">
                                                    Image Not Active
                                            </div>';
                                        }   
                                    ?>
                                </td>
                                <td><?php echo $featured;?></td>
                                <td><?php echo $active;?></td>
                                <td>
                                    
                                    <a href="#>" class="btn-update"><b>Update Food</b></a>
                                    <a href="#" class="btn-delete"><b>Delete Food</b></a>
                                    <!--<a href="manage-categories-delete.php" class="btn-delete"><b>Delete Admin</b></a>(? làm sao đẩy đúng id cho từng dòng HƠI lạ -->
                                </td>
                            </tr>
                                <?php               
                                }
                            }
                            else{                                
                                 echo'<div class="notification-success-update">DataBase Not Data</div>';
                            }
                        }
                        else{
                            echo "Cannot Connect To DataBase";
                        }
    
                ?>
            </table>
        </div>
    </div>
    
<?php include('z.element_web/footer.php') ?>
