<?php include('z.element_web/head.php') ?>
<?php //check get id.
    if(isset($_GET['id'])){
        $id = $_GET['id'];
        // get data in DB and display date in web.
        $sql_getData="SELECT * FROM tbl_category WHERE id=$id";

        $res= mysqli_query($connect_DB,$sql_getData);

        $count=mysqli_num_rows($res);
        if($count==1){
             $row=mysqli_fetch_assoc($res);
             $title=$row['title'];
             $curr_image=$row['image_name'];
             $feature=$row['featured'];
             $active=$row['active'];
             
        }
        else{
            $_SESSION['update_category']='
                <div class="notification-success-update">
                    Not Found Data!!!
                </div>
            ';
            header("location:".SITE_URL."admin/manage-admin.php");
        }
    }
    else{
        header('location:'.SITE_URL.'admin/manage-categories.php');
    }
?>


<div class="main-concept">
    <div class="wapper">
        <h2>UPDATE CATEGORIES</h2>
        <br>
        <form action="" method="POST" enctype="multipart/form-data">
                <table class="form-add-categories">
                    <tr>
                        <td>Title:</td>
                        <td><input type="text" name="title" value="<?php echo $title;?>"></td>
                    </tr>
                    <tr>
                        <td>Current Image:</td>
                        <td>
                            <?php
                                if($curr_image!=""){
                                    ?>
                                    <img class ="align_image" src="<?php echo SITE_URL;?>images/categories/<?php echo $curr_image;?>">
                                    <?php
                                }
                                else{
                                    echo '
                                    <div class ="align_text">
                                            Image Not Active
                                    </div>';
                                }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td>New Image:</td>
                        <td>
                            <input type="file" name="image">
                        </td>
                    </tr>
                    <tr>
                        <td>Featured:</td>
                        <td>
                            <input <?php if($feature=="Yes"){echo "checked";}?> type="radio" name="featured" value="Yes">&nbsp; Yes
                            <input <?php if($feature=="No"){echo "checked";}?> type="radio" name="featured" value="No">&nbsp; No
                        </td>
                    </tr>
                    <tr>
                        <td>Active:</td>
                        <td>
                            <input <?php if($active=="Yes"){echo "checked";}?>  type="radio" name="active" value="Yes">&nbsp; Yes
                            <input <?php if($active=="No"){echo "checked";}?> type="radio" name="active" value="No">&nbsp; No
                        <!--
                            <input type="radio" name="featured_yes" value="yes">&nbsp; Yes
                            <input type="radio" name="featured_no" value="no">&nbsp; No
                            name="featured_yes" khác nhau TRONG một trường click được 2 radio.
                            NẾU thiếu value mặc định là chọn <input type="radio" name="featured">&nbsp; Yes
                                dù có chọn no nhưng bên DB vẫn là on.
                        -->
                        </td>
                    </tr>
                    <tr>
                        <td closelog="2">
                            <input type="hidden" name='id' value="<?php echo $id;?>">
                            <input type="hidden" name='curr_name' value="<?php echo $curr_image;?>">
                            <input type="submit" name="submit" value="Update Categories" class="btn-submit">
                        </td>
                    </tr>
                </table>

            </form>
    
    <?php
    if(isset($_POST['submit'])){
        // get data form.
        $id=$_POST['id'];
        $title=$_POST['title'];
        $curr_image=$_POST['curr_name'];
        $feature=$_POST['featured'];
        $active=$_POST['active'];

        //handle image upload.
        if(!empty($_FILES['image']['name'])){// check giá trị của biến đó có trống hay ko..
            $image_name=$_FILES['image']['name'];
            if($image_name!=""){
            //A. Upload and Update image.
                // mở rộng.
                $tmp_ext=explode('.',$image_name);
                $ext=end($tmp_ext   );
                //rename -> để làm gì thì ko || có ý nghĩa gì thì không rõ.
                $image_name="Food_Category_".rand(000,200).'.'.$ext;

                $source_path=$_FILES['image']['tmp_name'];
                $destination_path="../images/categories/".$image_name;

                $upload=move_uploaded_file($source_path,$destination_path);
            
                if($upload==false){
                    $_SESSION['update_category']='
                    <div class="notification-success-add">
                            File Not Upload!!
                        <br>
                        <?php echo $destination_path;?>
                    </div>
                    ';
                    header("location:".SITE_URL."admin/manage-categories.php");
                    die();
                }
            //B.Remove curr_image.
                $remove_path="../images/categories".$curr_image;
                $remove=unlink($remove_path);
                // checked remove;
                if($remove_path==false){
                    $_SESSION['update_category']='
                    <div class="notification-success-add">
                            Can Not Remove File!!
                    </div>
                    ';
                    header("location:".SITE_URL."admin/manage-categories.php");
                    die();
                }
            }
            else{
                $image_name=$curr_image;
            }
        
        }
        else{
            $image_name=$curr_image;
        }

        //update DB.
        $sql_update="UPDATE tbl_category SET title='$title',image_name='$image_name', featured='$feature',active='$active' WHERE id=$id";
        $res_update=mysqli_query($connect_DB,$sql_update) or die(mysqli_error());
        if($res_update==true){// đẩy THÔNG BÁO qua page manage-admin.
            // // lưu THÔNG BÁO vào biến toàn cục $_SESSION + decorate.
            $_SESSION['update_category']='
                <div class="notification-success-update">
                    Update Categories Success
                </div>
            ';
            header("location:".SITE_URL."admin/manage-categories.php");// nhảy đến trang admin + dùng lệnh if nếu đúng -> xuất ra tại đó luôn.
        }
        else{
            $_SESSION['update_category']="Failed To Update Categories !!!";
            header("location:".SITE_URL."admin/manage-categories.php");
        }
    }
    ?>

    </div>
</div>




<?php include('z.element_web/footer.php') ?>