<html>
    <?php include('../config/constants.php')?>
    

    <head>
        <title>Login | Food Order</title>
        <link rel="stylesheet" href="../css/login.css">
    </head>

    <body>
        <?php if(isset($_SESSION['login'])){
            echo $_SESSION['login'];
            unset($_SESSION['login']);
        }
        ?>
        <div class="login"> 
            <h2 class="btn_login">LOGIN</h2>
            <!--Tạo form Login-->
            <br>
            <br>
            <form action="" method="POST" class="form">
                <div class="form_row">
                    <label for="user_name">User Name:</label><br>
                    <input type="text" id="user_name" name="user_name" size=30% placeholder="Enter your user name" >
                </div>
                <div class="form_row">
                    <label for="password">Password:</label><br>
                    <input type="password" id="password" name="password" size=30% placeholder="Enter your password">
                </div>
                <div class="form_row">
                    <input type="submit" name="submit" value="Submit" class="btn">
                </div>
            </form>

            <br><br><br><br><br>
            <p><span style="font-weight:bold; color:black">Create by _ </span><a href="#" tagert="_blank" style="font-weight:bold; text-decoration: none; color:rgb(230, 182, 230);">Pham Nhat Khanh</a></p>
        </div>
    </body>

    <!-- Checked user + password:-->
    <?php
        if(isset($_POST['submit'])){
            // Get data form
            $user_name=$_POST['user_name'];
            $password=$_POST['password'];
            //Create query
            $sql="SELECT * FROM tbl_admin WHERE username='$user_name' AND password='$password'";
            //
            $res=mysqli_query($connect_DB,$sql);
            //checked
            $count=mysqli_num_rows($res); 
            if($count==1){
                $_SESSION['login']='
                    <div class="notification-success-update">
                        Login Success.
                    </div>
                ';
                header("location:".SITE_URL."admin/");
            }else{
                $_SESSION['login']='
                    <div class="notification-fail-login">
                        Username Or Password InCorrect.
                        Please Enter Data Again !!
                    </div>
                ';
                header("location:".SITE_URL."admin/0.login.php");
            }
        }


    ?>
</html>