

<?php include('z.element_web/head.php') ?>

<!--CONTENT WEB-->
<div class="main-concept">
    <div class="wapper">
        <h2>ADD FOOD</h2>
        <br>
        <form action="" method="POST" enctype="multipart/form-data">
                <table class="form-add-categories">

                        <td>Categories:</td>
                        <td>
                            <select name="list_categories">
                                <?php
                                    $sql_category="SELECT * FROM tbl_category WHERE active='Yes'";
                                    $res_categoy=mysqli_query($connect_DB,$sql_category);
                                    $count=mysqli_num_rows($res_categoy);
                                    while($row=mysqli_fetch_assoc($res)){
                                        $category_id=$row['id'];
                                        $category_title=$row['title'];
                                    ?>
                                        <option value="<?php echo $category_id;?>"><?php echo $category_title;?></option>
                                  
    
                            </select>
                        </td>
                    </tr>

                </table>

            </form>
    </div>
</div>


<?php include('z.element_web/footer.php') ?>
