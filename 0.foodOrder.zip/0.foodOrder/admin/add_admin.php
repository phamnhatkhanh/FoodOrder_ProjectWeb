<!--
    1. Tạo trang Add-Admin + Css:
        -> web.
    2. Nhấn btn-add 
        -> chuyển sang trang khác.
    3. Thiết kế tran btn-add + tạo form:
        -> lấy thông tin + lưu vào DB.
    4. Tạo thông báo qua bên trang Add-Admin.
    5. Đẩy data từ DB lên trang Add-Admin.
-->
<?php include ('z.element_web/head.php') ?>

    <!--CONTENT WEB-->
    <div class="main-concept">
        <div class="wapper">
            <h2>ADD ADMIN</h2>

<!--Tạo Form-->
            <form action="" method="POST">
                <table class="form-add-admin">
                    <tr>
                        <td>Your Name:</td>
                        <td><input type="text" name="your_name" value='' placeholder="Enter your name..."></td>
                    </tr>
                    <tr>
                        <td>User Name:</td>
                        <td><input type="text" name="user_name" placeholder="Enter user name..."></td>
                    </tr>
                    <tr>
                        <td>Password: </td>
                        <td><input type="password" name="password" placeholder="Enter password..."></td>
                    </tr>
                    <tr>
                        <td closelog="2">
                            <input type="submit" name="submit" value="Add Admin" class="btn-submit">
                        </td>
                    </tr>
                </table>

            </form>
        </div>
    </div>
    
<?php include ('z.element_web/footer.php') ?>

<!--Kết nối + Dưa dữ liệu vào DB -->
<?php 

// Chuẩn hóa DATA đầu vào DB.
if(($_POST['your_name'] =='')||($_POST['user_name']=='')||($_POST['password']=='')){
    // (?# f5 mat nhu manage-admin.
    $_SESSION['add_admin']='<div style="margin-top:5%;text-align:center; font-weight:bold;">Please fill out all information on the application form !!!</div>';

    //echo "Please fill out all information on the application form !!!";
}
else{
    // khai bao chua du lieu.
    $Your_name = $_POST['your_name'];
    $User_name = $_POST['user_name'];
    $Password = $_POST['password']; /*  */

    //Create query SQL.
        $sql = "INSERT tbl_admin SET
            fullname='$Your_name',
            username='$User_name',
            password='$Password'
        ";
    // '$' xuat ra ca ten bien luon (? Sao ma bk lay ra duoc gia tri.

    // Excuting query.
        //1. constans.php: connect_DB + select_DB.
        $res=mysqli_query($connect_DB,$sql) or die(mysqli_error());

    //Noficaton:Check -> lưu thông báo: XONG đẩy qua site manage-admin.
        if($res==true){
            $_SESSION['add_admin']='
            <div class="notification-success-add">
                Add Admin Success
            </div>
            ';
            //$_SESSION['add']: add tùy ý đặt chỉ có lq tới SESSION.ADD ~~ column.
            //unset($_SESSION['add']);
            header("location:".SITE_URL."admin/manage-admin.php");
            //echo "Add admin sucess";
        }else{
            $_SESSION['add_admin']="Faile To Add Admin";
            header("location:".SITE_URL."admin/manage-admin.php");
            //echo"Error";
        }
    }

    /*
    *luu vao DB.
    day Data Db -> ra trang cua minh.
    */
    
?>

<!--Ntification-->
<?php 
                if(isset($_SESSION['add'])){
                    echo $_SESSION['add'];
                    unset($_SESSION['add']);
                }
            ?>