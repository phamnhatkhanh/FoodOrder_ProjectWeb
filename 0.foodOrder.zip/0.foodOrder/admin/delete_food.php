<?php
   //echo" Delete Page"
   // Check whether the id and image_name is set or not
   include('../config/constants.php');// Connection To DB.

   if(isset($_GET['id']) AND isset($_GET['image_name']))
   {
       // get the value and Delete
      //echo" Get value and Delete";
      $id = $_GET['id'];
      $image_name = $_GET['image_name'];
      echo $id."&ebsp".$image_name;
      
      //remove the physical imagafile is available
      if($image_name != ""){
          //Image is Available. So remove it
          $path = "../images/food/".$image_name;
          //remove the Image
          $remove = unlink($path);
         // IF failed to remove image then and an error message and stop the process
         if($remove==false){
             //set the session Message
             $_SESSION['remove'] = "<div class='notification-success-delete'>Faile to Remove Food Image.</div>";
             //REdirect to manage category page
             header('location:'.SITE_URL.'admin/manage-food.php');
             //stop  the process
             die();
            }
       }
       
      //Delete Data(image) from Database
      //sql query to delete data from database
      $sql = " DELETE FROM tbl_food WHERE id=$id";
      //execute the query
      $res = mysqli_query($connect_DB,$sql);

      //check whether the data is delete from  database or not 
      if($res==true){
          //set success message and redirect
          $_SESSION['delete']='
            <div class="notification-success-delete">
                Delete Food Success
            </div>
        ';
          //redirect to manage category
          header('location:'.SITE_URL.'admin/manage-food.php');      
        }
        else
        {
           //set fail message and redirect  
           $_SESSION['delete'] = "<div class='success'>Failed to Delete Food.</div>";
           //redirct to Manage Category
           header('location:'.SITE_URL.'admin/manage-food.php');
        }
    }
   else{
       //redirect to Manage Category Page
       $_SESSION['remove'] = "<div class='notification-success-delete'>Faile to Delete Food Image.</div>";
       header( 'location:'.SITE_URL.'admin/manage-food.php');
   }

?>