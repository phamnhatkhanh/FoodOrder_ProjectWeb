

<?php include('z.element_web/head.php') ?>

    <!--CONTENT WEB-->
    <div class="main-concept">
        <div class="wapper">
            <h2>ADD FOOD</h2>
            <br>
            <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form-add-categories">
                        <tr>
                            <td>Title:</td>
                            <td><input type="text" name="title" style="width: 15em"  placeholder="Enter title food..."></td>
                        </tr>
                        <tr>
                            <td>Description:</td>
                            <td><textarea name="description" style="width: 15em" rows="5" placeholder="Description of the food..."></textarea></td>
                        </tr>
                        <tr>
                            <td>Price:</td>
                            <td>
                                <input type="number" name="price" style="width: 15em">
                            </td>
                        </tr>
                        <tr>
                            <td>Select Image:</td>
                            <td>
                                <input type="file" name="image_food">
                            </td>
                        </tr>
                        <tr>
                            <td>Categories:</td>
                            <td>
                                <select name="category">

                                    <?php //push kind categoris from DB
                                        $sql_category="SELECT * FROM tbl_category WHERE active='Yes'";
                                        $res_categoy=mysqli_query($connect_DB,$sql_category);
                                        $count=mysqli_num_rows($res_categoy);
                                        if($count >0){
                                            while($row=mysqli_fetch_assoc($res_categoy)){
                                                $category_id=$row['id'];
                                                $category_kind=$row['title'];
                                                ?>
                                                    <option value="<?php echo $category_id;?>"><?php echo $category_kind;?></option>
                                                <?php
                                            }
                                    
                                        }
                                        else{
                                            // empty
                                            ?>
                                                <option value="0">Catgories Empty</option>
                                            <?php
                                        }
                                    ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>Featured:</td>
                            <td>
                                <input type="radio" name="featured" value="Yes">&nbsp; Yes
                                <input type="radio" name="featured" value="No">&nbsp; No
                            </td>
                        </tr>
                        <tr>
                            <td>Active:</td>
                            <td>
                                <input type="radio" name="active" value="Yes">&nbsp; Yes
                                <input type="radio" name="active" value="No">&nbsp; No
                            </td>
                        </tr>
                        <tr>
                            <td closelog="2">
                                <input type="submit" name="submit" value="Add Categories" class="btn-submit">
                            </td>
                        </tr>
                    </table>

                </form>
        </div>
    </div>
<?php
        if(isset($_POST['submit'])){
        // Get information.
            $title=$_POST['title'];
            $description=$_POST['description'];
            $price=$_POST['price'];
            $category=$_POST['category'];
            
            //  Check featured and active check or not if not set radious "No"
            if(isset($_POST['featured'])){
                $featured=$_POST['featured'];
            }else{
                $featured="No";
            }
            if(isset($_POST['active'])){
                $active=$_POST['active'];
            }else{
                $active="No";
            }


            // handling image upload.
            if(!empty($_FILES['image_food']['name'])){// check giá trị của biến đó có trống hay ko..
                $image_name=$_FILES['image_food']['name'];
                if($image_name!=""){
                    // mở rộng.
                    $tmp_ext=explode('.',$image_name);// do  end yêu cầu một tham chiếu
                    $ext=end($tmp_ext);
                    //rename -> để làm gì thì ko || có ý nghĩa gì thì không rõ.
                    $image_name="Food_Image".rand(000,200).'.'.$ext;

                    $source_path=$_FILES['image_food']['tmp_name'];
                    $destination_path="../images/food/".$image_name;

                    $upload=move_uploaded_file($source_path,$destination_path);

                    if($upload==false){
                        $_SESSION['add_food']='
                        <div class="notification-success-add">
                                File Not Upload!!
                            <br>
                            <?php echo $destination_path;?>
                        </div>
                        ';
                        header("location:".SITE_URL."admin/add_food.php");
                        die();
                    }
                }  
            }else{
                $image_name="";
            }
       
        // Insert data.
           $sql = "INSERT INTO `tbl_food`( `title`, `description`, `price`, `image_name`, `category_id`, `fearture`, `active`) 
                    VALUES ('$title','$description',$price,'$image_name',$category,'$featured','$active')
            ";

            $res=mysqli_query($connect_DB,$sql) or die(mysqli_error());

            if($res==true){
                $_SESSION['add_food']='
                <div class="notification-success-add">
                    Add Food Success 
                </div>
                ';
                
                //header("location:".SITE_URL."admin/manage-food.php");
                

            }else{
                $_SESSION['add_food']="Faile To Add Food";
                header("location:".SITE_URL."admin/manage-food.php");
                //echo"Error";
            }

        }
?>
 
<?php include('z.element_web/footer.php') ?>
