<?php include('z.element_web/head.php')?>

<div class="main-concept">
    <div class="wapper">
        <h2>UPDATE PASSWORD</h2>

        <?php // Mục đích là để lấy id từ manage-add qua:
            if(isset($_GET['id'])){//(? dùng isset()kiểm tra nhằm mục đích gì.
                $id=$_GET['id'];
            }
            ?>
        
        <!--Tạo form điền pass vào.-->
        <form action="" method="POST" autocomplete="off"> 
                <table class="form-add-admin">
                    <tr>
                    <td>Current Password:</td>
                        <td>
                            <input type="password" name="current_pass" placeholder="Your current password"size=25 id="current_pass">
                            <br>
                            <input type="checkbox" onclick="show_curr_pass()">Show Password
                            <script>
                                function show_curr_pass() {
                                    var x = document.getElementById("current_pass");
                                    if (x.type === "password") {
                                        x.type = "text";
                                    } else {
                                        x.type = "password";
                                    }
                                }
                            </script>
                        </td>
                    </tr>
                    <tr>
                        <td>New Password:</td>
                        <td>
                            <input type="password" name="new_pass" placeholder="Please enter a new password..." size=25 id="new_pass">
 
                        </td>
                    </tr>
                    <tr>
                        
                    <td>Confirm Password:</td>
                        <td>
                            <input type="password" name="confirm_pass" placeholder="Please confirm password..."size=25 id="confirm_pass">                           
                        </td>
                    </tr>
                    <tr>
                        <td closelog="2">
                            <input type="hidden" name='id' value="<?php echo $id;?>">
                            <input type="submit" name="changed_pass" value="Changed Password" class="btn-submit">
                        </td>
                    </tr>
                </table>

            </form>
    </div>
</div>

<?php include('z.element_web/footer.php')?>

<!--Xử lý - Check - Update pass DB-->
<?php

//khi click vào btn changed pass.
if(isset($_POST['changed_pass'])){

//1.Get data form POST.
    $id=$_POST['id'];
    $current_pass=$_POST['current_pass'];
    $new_pass=$_POST['new_pass'];
    $confirm_pass=$_POST['confirm_pass'];

//2.Check Data: curr _ pass_DB -- new _ confirm ADD Change pass and Save Data if all statements true.

    //curr _ pass_DB 
    $sql="SELECT * FROM tbl_admin WHERE id='$id' AND password='$current_pass'";
    $res=mysqli_query($connect_DB,$sql);

    //Kiểm tra: thỏa DK - DB có trống ko.
    if($res==true){

        // Dung Pass
        $count=mysqli_num_rows($res);
        if($count==1){

            //tiếp tục kiểm tra xem new _ confirm_pass đúng không.
            if($new_pass==$confirm_pass){
                // update pass
                $sql="UPDATE tbl_admin SET password='$new_pass' WHERE id=$id";
                $res=mysqli_query($connect_DB,$sql);// actualy return true or false because use query UPDATE.
                if($res==true){
                    $_SESSION['update_pass']='
                    <div class="notification-success-update">
                        Changed Password Success.Congratulation!!!
                        <?php echo $new_pass;?>
                    </div>
                    ';
                header("location:".SITE_URL."admin/manage-admin.php");
                }
                else{
                    $_SESSION['update_pass']='
                    <div class="notification-success-update">
                        Fail To Changed Password Because Of A Certain Reason.
                        <br>
                        Please Try It Again If You Want It !!!
                    </div>
                    ';
                header("location:".SITE_URL."admin/manage-admin.php");
                }
            }
            else{
                // xac nhan pass sai -> tro lai managane-admin
                $_SESSION['update_pass']='
                <div class="notification-success-update">
                    You have entered the wrong password
                    <br>
                    <span style="font-weight:bold; color:#3a0313;">Please check the entered password !!!<span>
                </div>
                ';
                header("location:".SITE_URL."admin/manage-admin.php");
            }
        }
        else{
            // Sai Pass || empty DB -> tro lai managane-admin
        $_SESSION['update_pass']='
            <div class="notification-success-update">
                    User Not Found !!!
            </div>
        ';
        header("location:".SITE_URL."admin/manage-admin.php");
        }
    }
    /*else{
        // Sai Pass -> tro lai managane-admin
        $_SESSION['update_pass']='
                <div class="notification-success-update">
                    You Have Entered The Wrong Password !!!
                </div>
        ';
        header("location:".SITE_URL."admin/manage-admin.php");
    }
    KHÔNG BAO GIỜ CHAYJ VÀO ĐÂY DÙ CÓ NHẬP SAI VÌ:
     - Do câu query: SELECT true/false -> đều trả về 1 object -> $count LUÔN LUÔN  = 1
    */
    
    



//3.
}

?>