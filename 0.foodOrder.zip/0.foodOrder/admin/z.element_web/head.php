<?php include('../config/constants.php')?>

<html>
<head>
    <title>
        Welcom to Food Store - Pages Home 
    </title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <!--TASKBAR-->
    <div class="menu">
        <div class="wapper"><!--
                chia thêm vùng class để điều chỉnh kích thước giữa 2 lề NẾU chỉ tạo 1 div <div class="wapper menu">
                #$ nếu chia vùng div MÀ có 1 nội dung bên trong nữa nên chia thêm 1 vùng. 
            -->
            <ul>
                <li><a href="home.php"><strong>Home</strong> </a></li>
                <li><a href="manage-admin.php"><strong>Admin</strong> </a></li>
                <li><a href="manage-categories.php"><strong>Categories</strong> </a></li>
                <li><a href="manage-food.php"><strong>Food</strong> </a></li>
                <!--<li><a href="manage-order.php"><strong>Order</strong> </a></li>-->
                <li><a href="0.logout.php"><strong>LogOut</strong> </a></li>
            </ul>
        </div>
    </div>