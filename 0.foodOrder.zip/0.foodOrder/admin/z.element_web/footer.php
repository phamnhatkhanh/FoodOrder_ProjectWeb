
    <!--FOOTER-->
    <div class="footer">
        <div class="wapper">
            Copyright<sup>&#169;</sup> 2021 by - <a style="text-decoration: none;" href="https://www.facebook.com/profile.php?id=100006035415975" target="_blank"><strong>Pham Nhat Khanh</strong></a>
        </div>
    </div>
</body>

</head>
</html>