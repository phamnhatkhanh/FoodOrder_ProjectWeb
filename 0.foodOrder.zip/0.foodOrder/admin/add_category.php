<!--
    (? cái upload lên file ~ cảm giác là chỉ lưu tên file CÒN kích thước file nó đi đâu.
     - đổi tên của image vừa upload lên để làm j.
     - if(isset($_FILES['image']['name'])){// co ten dang hoang.
            //
        }else{
            $image_name="";
        }
        NẾU DÙNG isset lúc nào cũng sẽ vào if(load file) mà ko vào else.
        NÊU thay isset -> empty thì sẽ vào được 2 trường hợp.
-->

<?php include('z.element_web/head.php') ?>

    <!--CONTENT WEB-->
    <div class="main-concept">
        <div class="wapper">
            <h2>ADD CATEGORIES</h2>
            <br>
            <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form-add-categories">
                        <tr>
                            <td>Title:</td>
                            <td><input type="text" name="title"  placeholder="Enter title food..."></td>
                        </tr>
                        <tr>
                            <td>Select Image:</td>
                            <td>
                                <input type="file" name="image">
                            </td>
                        </tr>
                        <tr>
                            <td>Featured:</td>
                            <td>
                                <input type="radio" name="featured" value="Yes">&nbsp; Yes
                                <input type="radio" name="featured" value="No">&nbsp; No
                            </td>
                        </tr>
                        <tr>
                            <td>Active:</td>
                            <td>
                                <input type="radio" name="active" value="Yes">&nbsp; Yes
                                <input type="radio" name="active" value="No">&nbsp; No
                            <!--
                                <input type="radio" name="featured_yes" value="yes">&nbsp; Yes
                                <input type="radio" name="featured_no" value="no">&nbsp; No
                                name="featured_yes" khác nhau TRONG một trường click được 2 radio.
                                NẾU thiếu value mặc định là chọn <input type="radio" name="featured">&nbsp; Yes
                                 dù có chọn no nhưng bên DB vẫn là on.
                            -->
                            </td>
                        </tr>
                        <tr>
                            <td closelog="2">
                                <input type="submit" name="submit" value="Add Categories" class="btn-submit">
                            </td>
                        </tr>
                    </table>

                </form>
        </div>
    </div>

    <?php
        if(isset($_POST['submit'])){
        // Get information.
            $title=$_POST['title'];
            $featured=$_POST['featured'];
            $active=$_POST['active'];
            //print_r($_FILES['image']);
            //die();//break;

            // handling image upload.
            if(!empty($_FILES['image']['name'])){// check giá trị của biến đó có trống hay ko..
                $image_name=$_FILES['image']['name'];
                // mở rộng.
                $tmp_ext=explode('.',$image_name);// do  end yêu cầu một tham chiếu
                $ext=end($tmp_ext);
                //rename -> để làm gì thì ko || có ý nghĩa gì thì không rõ.
                $image_name="Food_Category_".rand(000,200).'.'.$ext;

                $source_path=$_FILES['image']['tmp_name'];
                $destination_path="../images/categories/".$image_name;

                $upload=move_uploaded_file($source_path,$destination_path);

                if($upload==false){
                    $_SESSION['add_category']='
                    <div class="notification-success-add">
                            File Not Upload!!
                        <br>
                        <?php echo $destination_path;?>
                    </div>
                    ';
                    header("location:".SITE_URL."admin/manage-categories.php");
                    die();
                }
            }else{
                $image_name="";
            }
       
        // Insert data.
            $sql = "INSERT tbl_category SET
                title='$title',
                image_name='$image_name',
                featured='$featured',
                active='$active'
            ";

            $res=mysqli_query($connect_DB,$sql) or die(mysqli_error());

            if($res==true){
                $_SESSION['add_category']='
                <div class="notification-success-add">
                    Add Category Success 
                </div>
                ';
                //$_SESSION['add']: add tùy ý đặt chỉ có lq tới SESSION.ADD ~~ column.
                //unset($_SESSION['add']);
                header("location:".SITE_URL."admin/manage-categories.php");
                //echo "Add admin sucess";
            }else{
                $_SESSION['add_category']="Faile To Add Category";
                header("location:".SITE_URL."admin/manage-categories.php");
                //echo"Error";
            }
        }
        
    ?>
<?php include('z.element_web/footer.php') ?>
