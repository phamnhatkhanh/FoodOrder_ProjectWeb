

<?php
        if(isset($_POST['submit'])){
            // Get information.
                $title=$_POST['title'];
                $description=$_POST['description'];
                $price=$_POST['price'];
                $category=$_POST['category'];
                $featured=$_POST['featured'];
                $active=$_POST['active'];
                echo $title;
                echo "<br>";
                echo $description;
                echo "<br>";
                echo $price;
                echo "<br>";
                echo $category;
                die();
            }
    ?>