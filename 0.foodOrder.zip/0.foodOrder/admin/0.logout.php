<?php
    include('../config/constants.php');
//session_start();//sẽ đăng ký phiên làm việc của người dùng trên Server, từ đó Server sẽ tạo ra một ID riêng không trùng lặp để nhận diện cho client hiện tại. Dòng này bắt buộc có.
    session_destroy();
    // do đó cần xóa phiên khỏi Server
    header("location:".SITE_URL."admin/0.login.php");
?>