<?php include('z.element_web/head.php') ?>
<!--
    - sao nó có thẻ tự tìm được file trong thư mục đó nhỉ ??.
-->
    <!--CONTENT WEB-->
    <div class="main-concept">
        <div class="wapper">
            <h2>MANAGE CATEGORIES</h2>
            <div>
                <?php
                    if(isset($_SESSION['add_category'])){
                        echo $_SESSION['add_category'];
                        unset($_SESSION['add_category']);
                    }

                    if(isset($_SESSION['update_category'])){
                        echo $_SESSION['update_category'];
                        unset($_SESSION['update_category']);
                    }
                    if(isset($_SESSION['delete_category'])){
                        echo $_SESSION['delete_category'];
                        unset($_SESSION['delete_category']);
                    }
                ?>
            </div>
            
            <br>
            <a href="<?php echo SITE_URL;?>admin/add_category.php" class="btn-add"><b>Add Categories</b></a>
            <br>
            <br>
            <table class="format-table">
                <tr>
                        <th>S.N</th>
                        <th>Title</th>
                        <th>Images</th>
                        <th>Featured</th>
                        <th>Active</th>
                        <th>Action</th>
                </tr>

                <?php // Lấy dữ liệu từ DB.
                    $sql="SELECT * FROM tbl_category";
                    $res=mysqli_query($connect_DB,$sql);
                    if($res==true){
                        $count=mysqli_num_rows($res);
                        $sn=1;
                        if($count>0){
                            while($row=mysqli_fetch_assoc($res)){
                                $id=$row['id'];
                                $title=$row['title'];
                                $image=$row['image_name'];
                                $featured=$row['featured'];
                                $active=$row['active'];
                            ?>
                        <tr>
                            <td><?php echo $sn++;?></td>
                            <td><?php echo $title;?></td>
                            
                            <td>
                                <?php
                                    if($image!=""){
                                    ?>
                                        <img class ="align_image" src="<?php echo SITE_URL;?>images/categories/<?php echo $image?>  "> <!--sao nó có thẻ tự tìm được file trong thư mục đó nhỉ ??--->
                                    <?php
                                    }else{
                                        echo '
                                        <div class ="align_text">
                                                Image Not Active
                                        </div>';
                                    }   
                                ?>
                            </td>
                            <td><?php echo $featured;?></td>
                            <td><?php echo $active;?></td>
                            <td>
                                
                                <a href="<?php echo SITE_URL;?>admin/update_category.php?id=<?php echo $id;?>" class="btn-update"><b>Update Categories</b></a>
                                <a href="<?php echo SITE_URL;?>admin/delete_category.php?id=<?php echo $id;?>&image_name=<?php echo $image;?>" class="btn-delete"><b>Delete Categories</b></a>
                                <!--<a href="manage-categories-delete.php" class="btn-delete"><b>Delete Admin</b></a>(? làm sao đẩy đúng id cho từng dòng HƠI lạ -->
                            </td>
                        </tr>
                            
                        <?php  
                            } 
                        }else{
                            echo'<div class="notification-success-update">DataBase Not Data</div>';
                        }
                    }else{
                        echo "Cannot Connect To DataBase";
                    }
                ?>
            </table>
        </div>
    </div>
    
<?php include('z.element_web/footer.php') ?>
