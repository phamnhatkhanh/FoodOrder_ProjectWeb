<?php include ('z.element_web/head.php') ?>

<?php //Lấy Data từ DB LƯU vào các biến.
//Get ID from manage-admin-add.php
    $id=$_GET['id'];//(? chưa hiểu sao có thể lấy được id luôn.

    //Create query select id
    $sql="SELECT * FROM tbl_admin WHERE id=$id";

    //Excute 
    $res= mysqli_query($connect_DB,$sql);//(? lưu được luôn cả 1 cái bảng luôn ???.

    //Checked
    if($res==true){
        $count=mysqli_num_rows($res);
        if($count==1){
            $row=mysqli_fetch_assoc($res);
            $full_name=$row['fullname'];
            $user_name=$row['username'];
        }
        else{
            header("location:".SITE_URL."admin/manage-admin.php");
        }
    }
    else{
        $_SESSION['update']="Error Data !!!";
        header("location:".SITE_URL."admin/manage-admin.php");
    }
        
?>

    <!--LAYOUT WEB + Đẩy data từ các biến vào các input-->
    <div class="main-concept">
        <div class="wapper">
            <h2>UPDATE ADMIN</h2>
            <?php 
                if(isset($_SESSION['update'])){
                    echo $_SESSION['update'];
                    unset($_SESSION['update']);
                }
            ?>
            <br>
<!--Tạo Form-->
            <form action="" method="POST">
                <table class="form-add-admin">
                    <tr>
                        <td>Your Name:</td>
                        <td><input type="text" name="your_name" value="<?php echo $full_name;?>"></td>
                    </tr>
                    <tr>
                        <td>User Name:</td>
                        <td><input type="text" name="user_name" value="<?php echo $user_name;?>"></td>
                    </tr>
                    
                    <tr>
                        <td closelog="2">
                            <input type="hidden" name='id' value="<?php echo $id;?>">
                            <input type="submit" name="submit" value="Update Admin" class="btn-submit">
                        </td>
                    </tr>
                </table>

            </form>
        </div>
    </div>
    
<?php include ('z.element_web/footer.php') ?>

<?php //Update Data
    if(isset($_POST['submit'])){
        $id=$_POST['id'];
        $full_name=$_POST['your_name'];
        $user_name=$_POST['user_name'];
        //Create query
        $sql="UPDATE tbl_admin SET fullname='$full_name', username='$user_name' WHERE id=$id";
        //(? Ko hiểu sao $_POST['your_name'] ko đc mà phải dùng biến @@ chắc do phía backgound.
        //(? Phạm vi của biến nó khoanh vùng bởi <?php?. 

        //Excuted query
        $res=mysqli_query($connect_DB,$sql) or die(mysqli_error());

        //Checked
        if($res==true){// đẩy THÔNG BÁO qua page manage-admin.
            // // lưu THÔNG BÁO vào biến toàn cục $_SESSION + decorate.
            $_SESSION['update']='
                <div class="notification-success-update">
                    Update Admin Success
                </div>
            ';
            header("location:".SITE_URL."admin/manage-admin.php");// nhảy đến trang admin + dùng lệnh if nếu đúng -> xuất ra tại đó luôn.
        }
        else{
            $_SESSION['update']="Failed To Update Admin !!!";
            header("location:".SITE_URL."admin/manage-admin.php");
    }
    }
    
// 50;13
?>