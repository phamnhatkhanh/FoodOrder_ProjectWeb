<?php include('z.element_web/head.php') ?>

    <!--CONTENT WEB-->
    <div class="main-concept">
        <div class="wapper">
            <h2>DASHBOARD</h2>

            <div style="margin-top:1%;">
                <?php 
                    if(isset($_SESSION['login'])){
                        echo $_SESSION['login'];
                        unset($_SESSION['login']);
                    }
                ?>
            </div>
          
            <div class="manage_categories">
                <strong>5</strong>
                <br>
                Categories
            </div>
    
            <div class="manage_categories">
                <strong>5</strong>
                <br>
                Categories
            </div>

            <div class="manage_categories">
                <strong>5</strong>
                <br>
                Categories
            </div>

            <div class="manage_categories">
                <strong>5</strong>
                <br>
                Categories
            </div>
            
            <div class="clear-fix"></div>
            
        </div>
    </div>
    
<?php include('z.element_web/footer.php') ?>