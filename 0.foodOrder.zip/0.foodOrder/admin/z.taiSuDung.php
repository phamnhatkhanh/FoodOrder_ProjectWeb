<!--comment-->
<>
<>
<!-- Về Ngôn Ngữ:
    - Thực hiện từ trong ra không phân biệt ngôn ngữ:
        VD:echo'<div class="notification-success-update">DataBase Not Data</div>';

-->

<!-- Connect - Push DB 
    //Connect DB
        - $connet_DB=mysqli_connect(LOCALHOST, DB_USERNAME, DB_PASSWORD) or die(mysqli_error());// connet to DB
        - $DB_select=mysqli_select_db($connet_DB,DB_NAME) or die(mysqli_error());
    //Create query
        - $sql = "INSERT tbl_admin SET
            fullname='$Your_name',
            username='$User_name',
            password='$Password'
        ";
    //Excuting query
        - $res=mysqli_query($connet_DB,$sql) or die(mysqli_error());
    //Check query
        - if($res==true){
            $_SESSION['add']="Add Admin Sucessfully";      
        }else{
            $_SESSION['add']="Faile To Add Admin";
        }
    // Nofication
        - <div><php 
                if(isset($_SESSION['add'])){
                    echo $_SESSION['add'];
                    unset($_SESSION['add']);
                }
            ></div>-->
<>
<>
<!-- Send Messges + div + decoration. 
#$$ có thể được chèn giữa 2 vùng chứa.VD: bt div1,div3 sẽ sát nhau ~ khi click THÀNH div1,div2,div3.
    
     $_SESSION['add']='Add Admin Success';

    BUT decorate: btn + color-text + backgroud.
    
     $_SESSION['add']='
            <div class="notification-success-add">
                Add Admin Success
            </div>
    ';
-->
<>
<>
<!-- Kỹ Thuật Giấu Code Phía Sau 1 Btn:
# KO dk + header() -> xử lý + điều hướng ngược lại trang web // dấu web: nơi xử lý code.
-->
<>
<>
<!-- Ẩn Hiển PassWord:
// 1. Cần input:type=password + checkbox
// 2. Gắn id cho id input + nhúng <script> vào// ~~ function.
<td>
    <input type="password" name="current_pass" placeholder="Your current password" size=25 id="current_pass">
    <br>
    <input type="checkbox" onclick="myFunction()">Show Password
    <script>
        function myFunction() {
            var x = document.getElementById("current_pass");
            if (x.type === "password") {
                x.type = "text";
            } else {
                x.type = "password";
            }
        }
    </script>
</td>
-->                        
<>
<>
<!-- dùng để upload file + rename.
    $image_name=$_FILES['image']['name'];

                // mở rộng.
                $ext=end(explode('.',$image_name));
                //rename -> để làm gì thì ko || có ý nghĩa gì thì không rõ.
                $image_name="Food_Category_".rand(000,200).'.'.$ext;

                $source_path=$_FILES['image']['tmp_name'];
                $destination_path="../images/categories/".$image_name;

                $upload=move_uploaded_file($source_path,$destination_path);
-->
<>
<>
<!-- lấy id từ DB sang pages:
     while($row=mysqli_fetch_assoc($res)){
        $id=$row['id'];
        
    <a href="<?php echo SITE_URL;?>admin/delete-category.php?id=<?php echo $id;?>" class="btn-delete"><b>Delete categories</b></a>
-->





<>
<>
<!--
    (? 
-->