<?php include('z.element_web/head.php') ?>

    <!--CONTENT WEB-->
    <div class="main-concept">
        <div class="wapper">
            <h2>MANAGE ADMIN</h2>

            <div><?php 
                if(isset($_SESSION['add_admin'])){
                    echo $_SESSION['add_admin']; // lưu được ngoài text + div +align của div -> lợi hại thật.
                    unset($_SESSION['add_admin']);
                }
                if(isset($_SESSION['delete'])){
                    echo $_SESSION['delete'];
                    unset($_SESSION['delete']);
                }
                if(isset($_SESSION['update'])){
                    echo $_SESSION['update'];
                    unset($_SESSION['update']);
                }
                if(isset($_SESSION['update_pass'])){
                    echo $_SESSION['update_pass'];
                    unset($_SESSION['update_pass']);
                }
            ?></div>
            
            <br>
            <a href="add_admin.php" class="btn-add"><b>Add Admin</b></a>
            <br>
            <br>
            <table class="format-table">
                <tr>
                        <th>S.N</th>
                        <th>Full Name</th>
                        <th>User Name</th>
                        <th>Action</th>
                    </tr>
                <!--Đẩy DATA từ DB vào Bảng-->
                <?php
                    //Create a query
                        $sql="SELECT * FROM tbl_admin";
                    // Excuting query
                        $res=mysqli_query($connect_DB,$sql);
                    //Check Excuting query
                        if($res==true){
                            $count=mysqli_num_rows($res);
                            $sn=1;
                            if($count>0){
                                while($row=mysqli_fetch_assoc($res)){
                                    $id=$row['id'];
                                    $full_name=$row['fullname'];
                                    $user_name=$row['username'];
                                    
                                ?>
                                <tr>
                                    <!--<td>?php echo"$id";?></td>-->
                                    <td><?php echo $sn++;?></td>
                                    <td><?php echo"$full_name";?></td>
                                    <td><?php echo"$user_name";?></td>
                                    <td>
                                        <a href="<?php echo SITE_URL;?>admin/change_pass.php?id=<?php echo $id;?>" class="btn_changes_pass"><b>Changed Password</b></a>
                                        <a href="<?php echo SITE_URL;?>admin/update_admin.php?id=<?php echo $id;?>" class="btn-update"><b>Update Admin</b></a>
                                        <a href="<?php echo SITE_URL;?>admin/delete_admin.php?id=<?php echo $id;?>" class="btn-delete"><b>Delete Admin</b></a>
                                        <!--<a href="manage-admin-delete.php" class="btn-delete"><b>Delete Admin</b></a>(? làm sao đẩy đúng id cho từng dòng HƠI lạ -->
                                    </td>
                                </tr>
                                <?php               
                                }
                            }
                            else{                                
                                 echo'<div class="notification-success-update">DataBase Not Data</div>';
                            }
                        }
                        else{
                            echo "Cannot Connect To DataBase";
                        }
                        // <?php như ngôn NHÚNG vào $$ dù tách ra(như trên) THÌ hđ NHƯ là khối.
                        // kết nối DB lên web còn dễ hơn bên C#.
                ?>
            </table>
        </div>
    </div>
    
<?php include('z.element_web/footer.php') ?>
<!-- NHAP:
    <table class="format-table">
                <tr>
                    <th>S.N</th>
                    <th>FullName</th>
                    <th>UserName</th>
                    <th>Action</th>
                </tr>
                <tr>
                    <td>1.</td>
                    <td>Pham Nhat Khanh</td>
                    <td>khanhhcm4@gmail.com</td>
                    <td>
                        <a href="#" class="btn-update"><b>Update Admin</b></a>
                        <a href="#" class="btn-delete"><b>Delete Admin</b></a> 
                    </td>
                </tr>
                <tr>
                    <td>2.</td>
                    <td>Pham Nhat Khanh</td>
                    <td>khanhhcm4@gmail.com</td>
                    <td>
                        <a href="#" class="btn-update"><b>Update Admin</b></a>
                        <a href="#" class="btn-delete"><b>Delete Admin</b></a> 
                    </td>
                </tr>
                <tr>
                    <td>3.</td>
                    <td>Pham Nhat Khanh</td>
                    <td>khanhhcm4@gmail.com</td>
                    <td>
                        <a href="#" class="btn-update"><b>Update Admin</b></a>
                        <a href="#" class="btn-delete"><b>Delete Admin</b></a> 

                    </td>
                </tr>
            </table>
-->