<?php
    include('../config/constants.php');// Connection To DB.
    
    //Get ID from manage-admin-add.php
    $id=$_GET['id'];
        // (?<a href="<?php echo SITE_URL;?admin/manage-admin-delete.php?id=<?php echo $id;?" class="btn-delete"><b>Delete Admin</b></a>
        // ssao có thể từ lênh từ trang admin -> lấy id sang delete.
    
    //Create query
    $sql="DELETE FROM tbl_admin WHERE id= $id";

    //Excuted query
    $res=mysqli_query($connect_DB,$sql) or die(mysqli_error());

    //Checked
    if($res==true){// đẩy THÔNG BÁO qua page manage-admin.
        // // lưu THÔNG BÁO vào biến toàn cục $_SESSION + decorate.
        $_SESSION['delete']='
            <div class="notification-success-delete">
                Delete Admin Success
            </div>
        ';
        header("location:".SITE_URL."admin/manage-admin.php");// nhảy đến trang admin + dùng lệnh if nếu đúng -> xuất ra tại đó luôn.
    }
    else{
        $_SESSION['delete']="Failed To Delete Admin !!!";
        header("location:".SITE_URL."admin/manage-admin.php");
    }

/**
 *- Nếu ko có dk gì khi click vào btn delete hd như trên 1 trang web: btn -> xóa DB -> xog.
 * NHƯNG nếu có DK THÌ sẽ thấy rõ:
 *- Lấy id chuyển sang pages:manage-admin-delete -> xử lý -> điều hướng ngược lại pages manage-admin
 */
?>