
<?php

    session_start();//sẽ đăng ký phiên làm việc của người dùng trên Server, từ đó Server sẽ tạo ra một ID riêng không trùng lặp để nhận diện cho client hiện tại. Dòng này bắt buộc có.

    //Create constants to store non repeating value
    //VD: 1 Htg có 1000 trang -> chuyển các lệnh thành 1 file: tiết kiệm code,soures.
    define('SITE_URL','http://localhost/0.foodOrder/');
    define('LOCALHOST','localhost');
    define('DB_USERNAME','root');// nếu muốn thay đổi password || user -> ko cần chỉnh lại code trong 1 đống web pages.
    define('DB_PASSWORD','');
    define('DB_NAME','foodorder');
    
    //! chỗ connect dễ bị sai  THƯỜNG thì mình bắt chước -> sai khó sửa (? CẦN TÌM HIỂU THÊM
    $connect_DB=mysqli_connect(LOCALHOST, DB_USERNAME, DB_PASSWORD) or die(mysqli_error());// connet to DB
    $DB_select=mysqli_select_db($connect_DB,DB_NAME) or die(mysqli_error());// select DB.

    //(? mysqli:connet,select TRONG này ko gợi ý -> sao thông qua PHP + hàm có thể kết nói tới DB ~ ko gợi nhắc.
?>