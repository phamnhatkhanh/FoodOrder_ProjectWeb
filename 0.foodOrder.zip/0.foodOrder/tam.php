                <!--Đẩy DATA từ DB vào Bảng-->
                <?php
                    //Create a query
                        $sql="SELECT * FROM tbl_admin";
                    // Excuting query
                        $res=mysqli_query($connect_DB,$sql);
                    //Check Excuting query
                        if($res==true){
                            $count=mysqli_num_rows($res);
                            $sn=1;
                            if($count>0){
                                while($row=mysqli_fetch_assoc($res)){
                                    $id=$row['id'];
                                    $full_name=$row['fullname'];
                                    $user_name=$row['username'];
                                    
                                ?>
                                    <tr>
                                    <!--<td>?php echo"$id";?></td>-->
                                    <td><?php echo $sn++;?></td>
                                    <td><?php echo"$full_name";?></td>
                                    <td><?php echo"$user_name";?></td>
                                    <td>
                                        <a href="<?php echo SITE_URL;?>admin/manage-admin-update-password.php?id=<?php echo $id;?>" class="btn_changes_pass"><b>Changed Password</b></a>
                                        <a href="<?php echo SITE_URL;?>admin/manage-admin-update.php?id=<?php echo $id;?>" class="btn-update"><b>Update Admin</b></a>
                                        <a href="<?php echo SITE_URL;?>admin/manage-admin-delete.php?id=<?php echo $id;?>" class="btn-delete"><b>Delete Admin</b></a>
                                        <!--<a href="manage-admin-delete.php" class="btn-delete"><b>Delete Admin</b></a>(? làm sao đẩy đúng id cho từng dòng HƠI lạ -->
                                    </td>
                                </tr>
                                <?php               
                                }
                            }
                            else{                                
                                 echo'<div class="notification-success-update">DataBase Not Data</div>';
                            }
                        }
                        else{
                            echo "Cannot Connect To DataBase";
                        }
                        // <?php như ngôn NHÚNG vào $$ dù tách ra(như trên) THÌ hđ NHƯ là khối.
                        // kết nối DB lên web còn dễ hơn bên C#.
                ?>